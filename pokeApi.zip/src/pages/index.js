import Home from "./Home";
import SinglePokemon from "./SinglePokemon";
import Pokemons from "./Pokemons";
import Berries from "./Berries";
import SingleBerry from "./SingleBerry";

import Errors from "./Error";

export { Home, SinglePokemon, Pokemons, Berries, Errors, SingleBerry };
